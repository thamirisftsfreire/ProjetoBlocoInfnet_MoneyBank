﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MB.Application.Interfaces
{
    public interface IWithdrawalAppService : ITransactionAppService
    {
    }
}
