﻿using System;

namespace MB.Application.ViewModels
{
    public class ATMViewModel
    {
        private bool _userIsAuthenticated;
    }
}
