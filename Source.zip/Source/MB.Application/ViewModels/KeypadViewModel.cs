﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MB.Application.ViewModels
{
    public class KeypadViewModel
    {
        public int GetInput(int input) { return input; }

    }
}
