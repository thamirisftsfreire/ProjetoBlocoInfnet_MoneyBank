﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MB.Application.ViewModels
{
    public class DepositSlotViewModel
    {
        public Boolean IsDepositEnvelopeReceived() { return true; }
    }
}
