﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MB.Application.ATM
{
    public class ATMAppService
    {
    }
}
