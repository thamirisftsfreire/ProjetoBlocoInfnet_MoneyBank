﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MB.Domain.Test.Specification
{
    class WithdrawalMustBeLessThanAvailableCashDispenserUTest
    {
    }
}
