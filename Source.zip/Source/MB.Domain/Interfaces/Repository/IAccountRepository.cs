﻿using MB.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace MB.Domain.Interfaces.Repository
{
    public interface IAccountRepository : IRepository<Account>
    {
    }
}
