﻿using MB.Domain.Entities;

namespace MB.Domain.Interfaces.Repository 
{ 
    public interface IClientRepository : IRepository<Client>
    {
    }
}
